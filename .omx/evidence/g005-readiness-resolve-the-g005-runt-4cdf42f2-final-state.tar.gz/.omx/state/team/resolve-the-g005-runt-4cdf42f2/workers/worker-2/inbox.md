# New Task Assignment

**Worker:** worker-2
**Task ID:** 2

## Task Description

Write tests and verify: Resolve the G005 runtime readiness contract blocker only. Reuse .omx/context/g005-review-blockers-20260808T073156Z.md. Do not mutate .omx/ultragoal or funding-trader. Use TDD. First add a real boundary test proving the current Gateway internal handler response fails Platform gatewayAdapter strict decoding. Record the expected RED evidence. Then separate runtime status detailed mode and accounts from runtime readiness strict documented ready boolean derived from account.Manager runtime authority. Update api/exchange-gateway/v1/internal-openapi.yaml and contract tests. Run focused GREEN and relevant regressions. No Docker. No credentials. No venue writes. No Live or private writes. Preserve Test and Live product semantics. Coordinate shared files. Commit worker changes. Report exact test evidence.

## Approved Handoff Context

### Leader-owned Ultragoal context

- Context kind: leader_owned_ultragoal_context
- Active goal: G005-migrate-funding-and-deliver-shared-t (Migrate Funding and deliver shared trading execution)
- Codex goal mode: aggregate
- Goals path: .omx/ultragoal/goals.json
- Ledger path: .omx/ultragoal/ledger.jsonl
- Checkpoint policy: fresh_leader_get_goal_required
- Team tasks/evidence feed leader checkpointing; workers do not own Ultragoal goal state.
- Workers must not create worker Ultragoal ledgers, mutate `.omx/ultragoal`, auto-launch Team from Ultragoal, or claim shell commands changed Codex goal state.
- Leader checkpoint command shape: omx ultragoal checkpoint --goal-id G005-migrate-funding-and-deliver-shared-t --status complete --evidence "<team evidence mentioning .omx/ultragoal and G005-migrate-funding-and-deliver-shared-t>" --codex-goal-json <fresh-active-get_goal-json-or-path>
- Final aggregate stories require leader final quality gates before `update_goal({status: "complete"})`, then a fresh `get_goal` snapshot and `--quality-gate-json`.


## Scrum / Team Goal Workflow

Objective: Complete assigned OMX team task 2 with verified evidence, preserving leader-owned audit.

Durable OMX source of truth:
- Existing team task files, task claims, lifecycle events, and leader audit remain the durable artifacts.
- This section is a logical Codex goal handoff only; it does not create separate per-worker goal JSON or leader-audit artifacts.

Source-of-truth rules:
- Existing team task files and claim lifecycle remain authoritative; this worker goal must reference task IDs 2 instead of creating a duplicate task list.
- Claim each task with `omx team api claim-task` before editing; use the task file claim/status as the current assignment record.
- Record completion evidence through `omx team api transition-task-status`; leader audit owns aggregate team completion.

Assigned task/claim references:
- Task 2: Test: Resolve the G005 runtime readiness contract blocker only. Reuse .omx/conte (status: pending; claim required before work)

Codex goal handoff guidance (truthful fallback only):
1. If goal tools are available in this worker thread, call `get_goal` before creating or completing a goal.
2. Call `create_goal` only when no active goal exists and the explicit worker objective above should become this thread's active objective.
3. Do not claim OMX shell commands mutated Codex goal state; shell/team APIs persist only OMX artifacts and task state.
4. Call `update_goal({status: "complete"})` only after assigned task transitions are complete and verification evidence is present for leader audit.

## Instructions

1. Resolve canonical team state root and read the task file at `<team_state_root>/team/resolve-the-g005-runt-4cdf42f2/tasks/task-2.json`
2. Task id format:
   - State/MCP APIs use `task_id: "2"` (not `"task-2"`).
3. Request a claim via CLI interop (`omx team api claim-task --json`)
4. Complete the work
5. After completing work, commit your changes before reporting completion:
   `git add -A && git commit -m "task: <task-subject>"`
   This ensures your changes are available for incremental integration into the leader branch.
6. Complete/fail via lifecycle transition API (`omx team api transition-task-status --json`) from `"in_progress"` to `"completed"` or `"failed"` (include `result`/`error`)
7. Use `omx team api release-task-claim --json` only for rollback to `pending`
8. Write `{"state": "idle", "updated_at": "<current ISO timestamp>"}` to your status file


## Team Coordination Gate

Use the lightweight path for independent fan-out: work your assigned scope, keep normal ACK/status updates, and avoid extra ceremony. Activate the coordinated Team Big Five / ATEM-inspired protocol only when task state or wording shows dependencies, shared files/surfaces, handoffs, integration, cross-boundary work, blocked lanes, or changing assumptions.


## Team Big Five / ATEM Coordination Protocol


### Team Coordination Protocol — Task 2

Activation reasons:
- cross_boundary_or_handoff_language

Use this concise coordination layer for interdependent or cross-boundary work:
- Shared mental model / single source of truth: treat task JSON, inbox, mailbox, approved handoff, and leader updates as canonical; restate changed assumptions before acting.
- Closed-loop communication / ACK-readback handoffs: acknowledge handoffs with what you understood, the artifact/path affected, owner, and next action.
- Mutual performance monitoring at boundaries: check upstream/downstream contracts, shared files, and verification evidence before completion.
- Backup behavior: if blocked, write blocked status with the smallest needed help/reassignment request and continue any safe unblocked slice.
- Adaptability checkpoint: when assumptions, dependencies, or verification results change, pause for a brief leader-facing update before widening scope.
- Team orientation: optimize for the team outcome, not just your local task; call out integration risks, missing tests, and peer impacts.

Completion evidence must mention either `Coordination protocol: coordinated - <handoffs/boundaries checked>` or `Coordination protocol: no boundary handoff - <why no boundary remained>`.


## Native Subagent Delegation Contract


### Native Subagent Delegation Contract — Task 2

- Delegation mode: auto
- Before doing more than 3 serial repo-search/read commands, spawn up to 3 Codex native subagents using model gpt-5.4-mini, wait for them, then integrate their findings before continuing.
- A parallel probe is required unless there is a documented skip reason.
- Keep subagent work independent, bounded, and inside this worker's task scope.
- Use child report format: bullets.
- If skipped, include `Subagent skip reason:` in your result and explain why serial work was safer or sufficient.

Role/probe subtask candidates:
- Debug/root-cause probe: trace likely failure paths and summarize evidence.
- Review probe: inspect risks, edge cases, and contract violations.
- Test probe: identify existing coverage and missing regression checks.
- Change-slice probe: isolate safe implementation slices and migration hazards.

Subagent evidence reporting fields:
- Subagents spawned: <count and task names>
- Subagent model: gpt-5.4-mini
- Findings integrated: <brief bullets>
- Serial searches before spawn: <number>

Delegation compliance evidence (required for completion):
- Include exactly one of these lines in the task completion `result` passed to `omx team api transition-task-status`:
  - `Subagent spawn evidence: <count, child task names/thread ids, and what findings were integrated>`
  - `Subagent skip reason: <why serial execution was safer/sufficient>`
- Completion is rejected with `missing_delegation_compliance_evidence` when this broad-task evidence is absent.


## Verification Requirements

## Verification Protocol

Verify the following task is complete: Write tests and verify: Resolve the G005 runtime readiness contract blocker only. Reuse .omx/context/g005-review-blockers-20260808T073156Z.md. Do not mutate .omx/ultragoal or funding-trader. Use TDD. First add a real boundary test proving the current Gateway internal handler response fails Platform gatewayAdapter strict decoding. Record the expected RED evidence. Then separate runtime status detailed mode and accounts from runtime readiness strict documented ready boolean derived from account.Manager runtime authority. Update api/exchange-gateway/v1/internal-openapi.yaml and contract tests. Run focused GREEN and relevant regressions. No Docker. No credentials. No venue writes. No Live or private writes. Preserve Test and Live product semantics. Coordinate shared files. Commit worker changes. Report exact test evidence.

### Required Evidence:

1. Run full type check (tsc --noEmit or equivalent)
2. Run test suite (focus on changed areas)
3. Run linter on modified files
4. Verify the feature/fix works end-to-end
5. Check for regressions in related functionality

Report: PASS/FAIL with command output for each check.

## Fix-Verify Loop

If verification fails:
1. Identify the root cause of each failure
2. Fix the issue (prefer minimal changes)
3. Re-run verification
4. Repeat up to 3 times
5. If still failing after 3 attempts, escalate with:
   - What was attempted
   - What failed and why
   - Recommended next steps

When marking completion, include structured verification evidence in your task result:
- `Verification:`
- One or more PASS/FAIL checks with command/output references

