#!/bin/sh
set -eu
cd '/Users/dddd/Documents/GitHub/BolterTrader/.omx/team/g005-integration-foll-53eabf43/worktrees/worker-1'
export OMX_TEAM_WORKER='g005-integration-follow-up-usi/worker-1'
export OMX_TEAM_INTERNAL_WORKER='g005-integration-foll-53eabf43/worker-1'
export OMX_LEADER_NODE_PATH='/Users/dddd/.nvm/versions/node/v25.5.0/bin/node'
export OMX_LEADER_CLI_PATH='/Users/dddd/.nvm/versions/node/v25.5.0/bin/codex'
export OMX_TMUX_HUD_OWNER='1'
export OMX_TEAM_STATE_ROOT='/Users/dddd/Documents/GitHub/BolterTrader/.omx/state'
export OMX_TEAM_LEADER_CWD='/Users/dddd/Documents/GitHub/BolterTrader'
export OMX_MODEL_INSTRUCTIONS_FILE='/Users/dddd/Documents/GitHub/BolterTrader/.omx/team/g005-integration-foll-53eabf43/worktrees/worker-1/AGENTS.md'
export OMX_TEAM_DISPLAY_NAME='g005-integration-follow-up-usi'
export OMX_TEAM_WORKTREE_PATH='/Users/dddd/Documents/GitHub/BolterTrader/.omx/team/g005-integration-foll-53eabf43/worktrees/worker-1'
export OMX_TEAM_WORKTREE_DETACHED='1'
exec '/bin/zsh' -c 'export PATH='\''/Users/dddd/.nvm/versions/node/v25.5.0/bin'\'':$PATH
exec '\''/Users/dddd/.nvm/versions/node/v25.5.0/bin/codex'\'' '\''-c'\'' '\''model_reasoning_effort="medium"'\'' '\''--model'\'' '\''gpt-5.6-sol'\'' '\''-c'\'' '\''model_instructions_file="/Users/dddd/Documents/GitHub/BolterTrader/.omx/team/g005-integration-foll-53eabf43/worktrees/worker-1/AGENTS.md"'\'' '\''--dangerously-bypass-approvals-and-sandbox'\'''